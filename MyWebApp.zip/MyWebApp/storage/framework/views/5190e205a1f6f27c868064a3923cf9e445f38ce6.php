<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task</title>
</head>
<body>
    <h1>Task</h1>
    <div>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>TASK</th>
                <th>AUTHOR</th>
                <th>EDIT</th>
                <th>DELETE</th>
            </tr>
            <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tasks->id); ?></td>
                    <td><?php echo e($tasks->task); ?></td>
                    <td><?php echo e($tasks->author); ?></td>
                    <td> 
                        <a href="<?php echo e(route('task.edit', ['tasks' => $tasks])); ?>">Edit</a>
                    </td>
                    <td> 
                        <form method="post" action="<?php echo e(route('task.delete', ['tasks' => $tasks])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <input type="submit" value="Delete" />
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div>
            <a href="<?php echo e(route('task.newtask')); ?>">Create New Task</a>
        </div>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\MyWebApp\resources\views/task/index.blade.php ENDPATH**/ ?>