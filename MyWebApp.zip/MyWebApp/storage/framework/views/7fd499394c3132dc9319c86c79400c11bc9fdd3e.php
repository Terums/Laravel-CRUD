<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Edit Task </h1>
    <div>
        <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
    <form method="post" action="<?php echo e(route('task.update', ['tasks' => $task])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
        <label>Task</label>
            <input type="text" name="task" placeholder="Task" value="<?php echo e($task->task); ?>"/>
        </div>
        <div>
        <label>Author</label>
            <input type="text" name="author" placeholder="Author"value="<?php echo e($task->author); ?>"/>
        </div>
        <div>
            <input type="submit" value="Update Task" />
        </div>

    </form>
</body>
</html><?php /**PATH D:\xampp\htdocs\MyWebApp\resources\views/task/edit.blade.php ENDPATH**/ ?>